<?php $T_P = get_template_directory_uri(); ?>   
<footer>
	<h4> Следуйте за нами </h4>

	<div id="anchorSocial" class="content baseSize">

	<?php bottomMenu();?>

	</div>
	<?php wp_footer();?>
        
        
        
</footer>


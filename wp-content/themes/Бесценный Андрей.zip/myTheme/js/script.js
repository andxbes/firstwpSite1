console.info("Подключили script");

